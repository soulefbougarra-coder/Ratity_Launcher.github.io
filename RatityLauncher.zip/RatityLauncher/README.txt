RATITY LAUNCHER
===============
1. Install Python 3.8+ (python.org, tick "Add Python to PATH") and Java 17 or 21.
2. Windows: double-click "Start Launcher.bat".   Mac/Linux: run ./start.sh
3. The launcher opens in your browser. Keep the black window open while you use it; close it to quit.

Optional:
  pip install pillow      -> shows every mod/pack icon
  pip install pywebview   -> opens as a normal app window instead of a browser tab

Your data lives in:  C:\Users\<you>\.mclauncher
Offline profile mode only (no Microsoft login). Fabric mods supported; Forge is not.

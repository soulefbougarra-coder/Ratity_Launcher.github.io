@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 mc_launcher.py
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    python mc_launcher.py
  ) else (
    echo Python 3 is not installed.
    echo Download it from https://www.python.org/downloads/ and tick "Add Python to PATH" during setup.
    pause
    exit /b
  )
)
if errorlevel 1 pause

#!/usr/bin/env python3
"""Mini Minecraft Launcher - downloads & launches Minecraft (Java), installs Fabric,
and manages mods / resource packs. Python 3.8+, no extra packages needed."""
import hashlib, io, json, os, platform, re, shutil, subprocess, threading, time, uuid, webbrowser, zipfile
import urllib.request, urllib.parse
import http.server
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = os.path.join(os.path.expanduser("~"), ".mclauncher")
MC = os.path.join(ROOT, "shared")          # versions / libraries / assets
CFG = os.path.join(ROOT, "config.json")
MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
OSN = {"Windows": "windows", "Darwin": "osx", "Linux": "linux"}.get(platform.system(), "linux")
SEP = ";" if OSN == "windows" else ":"
VERS = []
DL = {"threads": 16}
IMG = {}
# Tuned G1GC flags (Aikar's set): smoother frame times, fewer GC pauses
OPT_FLAGS = ("-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=50 "
             "-XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=30 "
             "-XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 "
             "-XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4 -XX:InitiatingHeapOccupancyPercent=15 "
             "-XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5 "
             "-XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1").split()
PERF_MODS = ["sodium", "lithium", "ferrite-core", "modernfix", "immediatelyfast", "entityculling"]


def total_ram_mb():
    try:
        if OSN == "windows":
            import ctypes

            class M(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("p", ctypes.c_ulong)] + [
                    (n, ctypes.c_ulonglong) for n in ("tp", "ap", "tf", "af", "tv", "av", "ae")]
            m = M()
            m.l = ctypes.sizeof(M)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.tp // 2 ** 20
        if OSN == "osx":
            return int(subprocess.check_output(["sysctl", "-n", "hw.memsize"])) // 2 ** 20
        with open("/proc/meminfo") as f:
            return int(f.readline().split()[1]) // 1024
    except Exception:
        return 8192


def resolve_ram(val, gd):
    """A number = use it. Anything else ('auto') = pick by installed mods and system RAM."""
    try:
        return max(1024, int(val))
    except (TypeError, ValueError):
        pass
    md = os.path.join(gd, "mods")
    mods = len(os.listdir(md)) if os.path.isdir(md) else 0
    want = 6144 if mods > 60 else 4096 if mods else 2048
    return max(1024, int(min(want, total_ram_mb() * 0.5) // 256 * 256))


def fetch(url, dest=None):
    req = urllib.request.Request(url, headers={"User-Agent": "MiniLauncher/1.0"})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read()
    if dest:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as f:
            f.write(data)
    return data


def getjson(url):
    return json.loads(fetch(url))


def download(url, dest, sha1=None):
    if os.path.exists(dest):
        if not sha1:
            return
        with open(dest, "rb") as f:
            if hashlib.sha1(f.read()).hexdigest() == sha1:
                return
    fetch(url, dest)


def allowed(rules):
    if not rules:
        return True
    ok = False
    for r in rules:
        m = True
        o = r.get("os")
        if o:
            if "name" in o and o["name"] != OSN:
                m = False
            if o.get("arch") == "x86" and platform.machine().lower() not in ("i386", "i686", "x86"):
                m = False
        if "features" in r:
            m = False
        if m:
            ok = r["action"] == "allow"
    return ok


def load_version(vid):
    p = os.path.join(MC, "versions", vid, vid + ".json")
    if not os.path.exists(p):
        url = next(v["url"] for v in VERS if v["id"] == vid)
        fetch(url, p)
    with open(p) as f:
        v = json.load(f)
    if "inheritsFrom" not in v:
        v["_jar"] = vid
        return v
    base = load_version(v["inheritsFrom"])
    m = dict(base)
    m.update({k: x for k, x in v.items() if k not in ("libraries", "arguments")})
    m["libraries"] = v.get("libraries", []) + base["libraries"]
    ba, va = base.get("arguments", {}), v.get("arguments", {})
    m["arguments"] = {k: ba.get(k, []) + va.get(k, []) for k in ("game", "jvm")}
    return m


def fabric_install(mc):
    """Cached for 7 days so launching doesn't need the network every time."""
    cache = os.path.join(MC, "versions", f"fabric-{mc}.id")
    try:
        with open(cache) as f:
            vid = f.read().strip()
        if not os.path.exists(os.path.join(MC, "versions", vid, vid + ".json")):
            vid = None
    except OSError:
        vid = None
    if vid and time.time() - os.path.getmtime(cache) < 7 * 86400:
        return vid
    try:
        vid = _fabric_fetch(mc)
        with open(cache, "w") as f:
            f.write(vid)
        return vid
    except Exception:
        if vid:
            return vid  # offline: use what we have
        raise


def _fabric_fetch(mc):
    loaders = getjson(f"https://meta.fabricmc.net/v2/versions/loader/{mc}")
    if not loaders:
        raise RuntimeError(f"Fabric doesn't support Minecraft {mc}")
    lv = next((l["loader"]["version"] for l in loaders if l["loader"].get("stable")),
              loaders[0]["loader"]["version"])
    url = f"https://meta.fabricmc.net/v2/versions/loader/{mc}/{lv}/profile/json"
    prof = getjson(url)
    p = os.path.join(MC, "versions", prof["id"], prof["id"] + ".json")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w") as f:
        json.dump(prof, f)
    return prof["id"]


def prepare(vid, gamedir, user, ram, java, progress, opt=True):
    v = load_version(vid)
    jar = os.path.join(MC, "versions", v["_jar"], v["_jar"] + ".jar")
    tasks = [(v["downloads"]["client"]["url"], jar, v["downloads"]["client"]["sha1"])]
    cp, nats = [], []
    for lib in v["libraries"]:
        if not allowed(lib.get("rules")):
            continue
        d = lib.get("downloads")
        if d is None:  # maven-style entry (Fabric)
            g, a, ver = lib["name"].split(":")[:3]
            rel = f"{g.replace('.', '/')}/{a}/{ver}/{a}-{ver}.jar"
            tasks.append((lib.get("url", "https://libraries.minecraft.net/") + rel,
                          os.path.join(MC, "libraries", rel), None))
            cp.append(os.path.join(MC, "libraries", rel))
            continue
        art = d.get("artifact")
        if art and art.get("url"):
            dest = os.path.join(MC, "libraries", art["path"])
            tasks.append((art["url"], dest, art["sha1"]))
            cp.append(dest)
        nat = lib.get("natives")
        if nat and OSN in nat:
            c = d["classifiers"][nat[OSN].replace("${arch}", "64")]
            dest = os.path.join(MC, "libraries", c["path"])
            tasks.append((c["url"], dest, c["sha1"]))
            nats.append(dest)
    marker = os.path.join(MC, "versions", vid, ".verified")
    fast = os.path.exists(marker)  # already fully downloaded: skip hashing/checking
    ai = v["assetIndex"]
    idx_path = os.path.join(MC, "assets", "indexes", ai["id"] + ".json")
    download(ai["url"], idx_path, ai["sha1"])
    with open(idx_path) as f:
        objs = json.load(f)["objects"]
    for h in {o["hash"] for o in objs.values()}:
        tasks.append((f"https://resources.download.minecraft.net/{h[:2]}/{h}",
                      os.path.join(MC, "assets", "objects", h[:2], h), None))
    if fast:
        tasks = []
    done = 0
    with ThreadPoolExecutor(DL["threads"]) as pool:
        futs = [pool.submit(download, *t) for t in tasks]
        for fu in as_completed(futs):
            fu.result()
            done += 1
            progress(f"Downloading files… {done}/{len(tasks)}", 100 * done / len(tasks))
    natdir = os.path.join(MC, "versions", vid, "natives")
    os.makedirs(natdir, exist_ok=True)
    for n in ([] if fast else nats):
        with zipfile.ZipFile(n) as z:
            for mem in z.namelist():
                if not mem.startswith("META-INF") and not mem.endswith("/"):
                    z.extract(mem, natdir)
    with open(marker, "w"):
        pass
    cp = list(dict.fromkeys(cp)) + [jar]
    uid = str(uuid.uuid3(uuid.NAMESPACE_OID, "OfflinePlayer:" + user))
    subs = {
        "auth_player_name": user, "version_name": vid, "game_directory": gamedir,
        "assets_root": os.path.join(MC, "assets"), "assets_index_name": ai["id"],
        "auth_uuid": uid, "auth_access_token": "0", "user_type": "legacy",
        "version_type": v.get("type", "release"), "natives_directory": natdir,
        "launcher_name": "MiniLauncher", "launcher_version": "1.0",
        "classpath": SEP.join(cp), "library_directory": os.path.join(MC, "libraries"),
        "classpath_separator": SEP, "clientid": "0", "auth_xuid": "0",
        "user_properties": "{}", "game_assets": os.path.join(MC, "assets", "virtual", "legacy"),
    }

    def sub(s):
        for k, x in subs.items():
            s = s.replace("${" + k + "}", x)
        return s

    def flat(args):
        out = []
        for a in args:
            if isinstance(a, str):
                out.append(a)
            elif allowed(a.get("rules")):
                out += [a["value"]] if isinstance(a["value"], str) else a["value"]
        return out

    if "arguments" in v:
        jvm, game = flat(v["arguments"]["jvm"]), flat(v["arguments"]["game"])
    else:  # pre-1.13 versions
        jvm = ["-Djava.library.path=${natives_directory}", "-cp", "${classpath}"]
        game = v["minecraftArguments"].split()
    ram = int(ram)
    flags = OPT_FLAGS if opt else []
    return [java, f"-Xms{max(512, ram // 2)}M", f"-Xmx{ram}M"] + flags + [sub(x) for x in jvm] + [v["mainClass"]] + [sub(x) for x in game]


try:
    from PIL import Image  # optional: lets us show WebP/large icons
except ImportError:
    Image = None
MR = "https://api.modrinth.com/v2"
BG, PANEL, FG, MUTED, ACC, ACC_FG = "#0c0c0e", "#17171b", "#f1f1f4", "#8a8a94", "#e8821e", "#ffffff"
CARD, LINE = "#16161a", "#2a2a30"
FONT = "Segoe UI"


def mr_search(kind, query, mc):
    facets = [[f"project_type:{kind}"], [f"versions:{mc}"]]
    if kind == "mod":
        facets.append(["categories:fabric"])
    q = urllib.parse.urlencode({"query": query, "facets": json.dumps(facets), "limit": 40,
                                "index": "relevance" if query else "downloads"})
    return getjson(f"{MR}/search?{q}")["hits"]


def mr_install(pid, mc, loader, dest, seen, top=True):
    if pid in seen:
        return []
    seen.add(pid)
    q = {"game_versions": json.dumps([mc])}
    if loader:
        q["loaders"] = json.dumps([loader])
    try:
        vs = getjson(f"{MR}/project/{pid}/version?{urllib.parse.urlencode(q)}")
        if not vs:
            raise RuntimeError(f"no version compatible with Minecraft {mc}")
        v = vs[0]
        f = next((x for x in v["files"] if x.get("primary")), v["files"][0])
        os.makedirs(dest, exist_ok=True)
        download(f["url"], os.path.join(dest, f["filename"]), f["hashes"].get("sha1"))
    except Exception:
        if top:
            raise
        return []
    names = [f["filename"]]
    for d in v.get("dependencies", []):
        if d["dependency_type"] == "required" and d.get("project_id"):
            names += mr_install(d["project_id"], mc, loader, dest, seen, False)
    return names


ICONS = {}  # project_id -> PhotoImage (keeps references alive)


def icon_file(h):
    """Download + cache a project icon as PNG; returns the path or None."""
    p = os.path.join(ROOT, "icons", h["project_id"] + ".png")
    if not os.path.exists(p):
        data = fetch(h["icon_url"])
        os.makedirs(os.path.dirname(p), exist_ok=True)
        if Image:
            im = Image.open(io.BytesIO(data)).convert("RGBA")
            im.thumbnail((28, 28))
            im.save(p)
        elif data[:4] == b"\x89PNG":
            with open(p, "wb") as f:
                f.write(data)
        else:
            return None
    return p


def postjson(url, body):
    req = urllib.request.Request(url, json.dumps(body).encode(),
                                 {"User-Agent": "MiniLauncher/1.0", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())


def sha1_of(p):
    with open(p, "rb") as f:
        return hashlib.sha1(f.read()).hexdigest()


def mr_updates(folder, mc, loader):
    """Returns [(old_filename, new_file_info, version_number)] for files with a newer version."""
    files = {sha1_of(os.path.join(folder, n)): n for n in os.listdir(folder)
             if os.path.isfile(os.path.join(folder, n))}
    if not files:
        return []
    body = {"hashes": list(files), "algorithm": "sha1", "game_versions": [mc]}
    if loader:
        body["loaders"] = [loader]
    out = []
    for h, v in postjson(MR + "/version_files/update", body).items():
        f = next((x for x in v["files"] if x.get("primary")), v["files"][0])
        if f["hashes"].get("sha1") != h:
            out.append((files[h], f, v["version_number"]))
    return out


# ======================= local web server (serves ./web and a JSON API) =======================
WEB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")
CFGF = os.path.join(ROOT, "ratity.json")
ST = {"text": "Launcher ready", "pct": 0, "running": False}
cfg = {"profile": "Default", "ver": "", "loader": "vanilla", "ram": "auto", "opt": True, "java": "java", "user": "Player"}
KIND = {"mods": ("mods", "mod", "fabric", ".jar"), "packs": ("resourcepacks", "resourcepack", None, ".zip")}
CHECK = {"profile": lambda v: isinstance(v, str) and v.strip(), "ver": lambda v: any(x["id"] == v for x in VERS),
         "loader": lambda v: v in ("vanilla", "fabric"),
         "ram": lambda v: str(v) == "auto" or (str(v).isdigit() and 1 <= int(v) <= 64),
         "opt": lambda v: isinstance(v, bool), "java": lambda v: isinstance(v, str) and v.strip(),
         "user": lambda v: isinstance(v, str) and re.fullmatch(r"\w{3,16}", v)}
PORT = 0
try:
    with open(CFGF) as f:
        cfg.update(json.load(f))
except Exception:
    pass


def save():
    os.makedirs(ROOT, exist_ok=True)
    with open(CFGF, "w") as f:
        json.dump(cfg, f, indent=1)


def say(text, pct=None):
    ST["text"] = text
    if pct is not None:
        ST["pct"] = pct


def inst(sub=""):
    d = os.path.join(ROOT, "instances", re.sub(r"[^\w.\- ]", "_", cfg["profile"].strip())[:40] or "Default", sub)
    os.makedirs(d, exist_ok=True)
    return d


def listing(sub):
    d = inst(sub)
    return [{"name": n, "size": os.path.getsize(os.path.join(d, n))} for n in sorted(os.listdir(d))
            if os.path.isfile(os.path.join(d, n)) and not n.endswith(".part")]


def load_manifest():
    mp = os.path.join(ROOT, "manifest.json")
    try:
        with open(mp) as f:
            VERS[:] = json.load(f)
    except Exception:
        pass
    try:
        fresh = getjson(MANIFEST)["versions"]
        VERS[:] = fresh
        os.makedirs(ROOT, exist_ok=True)
        with open(mp, "w") as f:
            json.dump(fresh, f)
    except Exception:
        if not VERS:
            say("Couldn't load the version list (check your internet).")


def api_state(q=None):
    rel = [v["id"] for v in VERS if v["type"] == "release"]
    if rel and cfg["ver"] not in rel:
        cfg["ver"] = rel[0]
    return {"cfg": cfg, "versions": rel, "mods": listing("mods"), "packs": listing("resourcepacks"),
            "sys": {"cpu": os.cpu_count(), "ram": total_ram_mb(), "os": f"{platform.system()} {platform.release()}"}, **ST}


def api_config(b):
    for k, ok in CHECK.items():
        if k in b:
            if not ok(b[k]):
                raise ValueError(f"Invalid value for {k}")
            cfg[k] = b[k]
    save()
    return api_state()


def api_search(q):
    sub, mt, _, _ = KIND[q["kind"]]
    return [{"id": h["project_id"], "title": h["title"], "author": h["author"], "downloads": h["downloads"],
             "desc": h["description"], "icon": h.get("icon_url") or ""} for h in mr_search(mt, q.get("q", ""), cfg["ver"])]


def api_install(b):
    sub, _, ld, _ = KIND[b["kind"]]
    if ld:
        cfg["loader"] = "fabric"
        save()
    return {"installed": mr_install(b["id"], cfg["ver"], ld, inst(sub), set())}


def api_updates(b):
    sub, _, ld, _ = KIND[b["kind"]]
    return [{"old": o, "new": f["filename"], "version": v} for o, f, v in mr_updates(inst(sub), cfg["ver"], ld)]


def api_apply(b):
    sub, _, ld, _ = KIND[b["kind"]]
    ups = mr_updates(inst(sub), cfg["ver"], ld)
    for old, f, _ in ups:
        download(f["url"], os.path.join(inst(sub), f["filename"]), f["hashes"].get("sha1"))
        if old != f["filename"]:
            os.remove(os.path.join(inst(sub), old))
    return {"updated": len(ups)}


def api_boost(b):
    cfg["loader"] = "fabric"
    save()
    seen, ok, bad = set(), [], []
    for slug in PERF_MODS:
        try:
            mr_install(slug, cfg["ver"], "fabric", inst("mods"), seen)
            ok.append(slug)
        except Exception:
            bad.append(slug)
    return {"ok": ok, "bad": bad}


def api_remove(b):
    sub = KIND[b["kind"]][0]
    p = os.path.join(inst(sub), os.path.basename(b["name"]))
    if os.path.isfile(p):
        os.remove(p)
    return {"ok": True}


def api_open(b):
    d = {"game": MC, "profiles": os.path.join(ROOT, "instances"), "mods": inst("mods"), "packs": inst("resourcepacks")}[b["what"]]
    os.makedirs(d, exist_ok=True)
    if OSN == "windows":
        os.startfile(d)
    else:
        subprocess.Popen(["open" if OSN == "osx" else "xdg-open", d])
    return {"ok": True}


def api_launch(b):
    if ST["running"]:
        raise ValueError("Minecraft is already running.")
    if not cfg["ver"]:
        raise ValueError("Pick a Minecraft version first.")
    ST["running"] = True
    threading.Thread(target=run_game, daemon=True).start()
    return {"ok": True}


def run_game():
    gd, mc = inst(), cfg["ver"]
    try:
        vid = fabric_install(mc) if cfg["loader"] == "fabric" else mc
        ram = resolve_ram("auto" if cfg["ram"] == "auto" else int(cfg["ram"]) * 1024, gd)
        cmd = prepare(vid, gd, cfg["user"], ram, cfg["java"], say, cfg["opt"])
        shutil.rmtree(os.path.join(gd, ".fabric", "remappedJars"), ignore_errors=True)
        with open(os.path.join(gd, "launcher.log"), "w") as log:
            proc = subprocess.Popen(cmd, cwd=gd, stdout=log, stderr=subprocess.STDOUT)
            say(f"Minecraft is running ({cfg['profile']})", 100)
            proc.wait()
        say(f"Game closed (exit code {proc.returncode}). See launcher.log in the profile folder if it crashed.", 0)
    except FileNotFoundError:
        say("Java not found. Install Java 17/21 or set the Java path in Settings.", 0)
    except Exception as e:
        say(f"Error: {e}", 0)
    ST["running"] = False


def upload(q, rfile, n):
    sub, _, _, ext = KIND[q["kind"]]
    name = os.path.basename(q.get("name", "")).strip()
    if not name.lower().endswith(ext) or name.startswith("."):
        raise ValueError(f"Only {ext} files can be added here.")
    if n > 400 * 2 ** 20:
        raise ValueError("File too large.")
    dest = os.path.join(inst(sub), name)
    with open(dest + ".part", "wb") as f:
        left = n
        while left:
            chunk = rfile.read(min(left, 1 << 20))
            if not chunk:
                break
            f.write(chunk)
            left -= len(chunk)
    os.replace(dest + ".part", dest)
    return {"ok": True}


GET = {"/api/state": api_state, "/api/status": lambda q: dict(ST), "/api/search": api_search}
POST = {"/api/config": api_config, "/api/launch": api_launch, "/api/install": api_install, "/api/updates": api_updates,
        "/api/apply": api_apply, "/api/boost": api_boost, "/api/remove": api_remove, "/api/open": api_open}
TYPES = {"index.html": "text/html; charset=utf-8", "style.css": "text/css", "renderer.js": "text/javascript"}


class H(http.server.BaseHTTPRequestHandler):
    def log_message(s, *a):
        pass

    def send(s, obj, code=200, ctype="application/json"):
        data = obj if isinstance(obj, bytes) else json.dumps(obj).encode()
        s.send_response(code)
        s.send_header("Content-Type", ctype)
        s.send_header("Content-Length", str(len(data)))
        s.send_header("Cache-Control", "no-store")
        s.end_headers()
        s.wfile.write(data)

    def host_ok(s):  # blocks other websites / DNS-rebinding from talking to the launcher
        return s.headers.get("Host", "") in (f"127.0.0.1:{PORT}", f"localhost:{PORT}")

    def do_GET(s):
        if not s.host_ok():
            return s.send({"error": "forbidden"}, 403)
        u = urllib.parse.urlparse(s.path)
        q, p = dict(urllib.parse.parse_qsl(u.query)), u.path
        try:
            if p in ("/", "/index.html", "/style.css", "/renderer.js"):
                name = "index.html" if p == "/" else p.lstrip("/")
                with open(os.path.join(WEB, name), "rb") as f:
                    return s.send(f.read(), 200, TYPES[name])
            if p.startswith("/icon/"):
                url = q.get("u", "")
                if not re.fullmatch(r"\w+", p[6:]) or not url.startswith("https://cdn.modrinth.com/"):
                    return s.send({"error": "bad icon"}, 400)
                path = icon_file({"project_id": p[6:], "icon_url": url})
                if not path:
                    return s.send({"error": "no icon"}, 404)
                with open(path, "rb") as f:
                    return s.send(f.read(), 200, "image/png")
            if p in GET:
                return s.send(GET[p](q))
            s.send({"error": "not found"}, 404)
        except Exception as e:
            s.send({"error": str(e)}, 400)

    def do_POST(s):
        if not s.host_ok() or s.headers.get("X-Launcher") != "1":
            return s.send({"error": "forbidden"}, 403)
        u = urllib.parse.urlparse(s.path)
        n = int(s.headers.get("Content-Length") or 0)
        try:
            if u.path == "/api/upload":
                return s.send(upload(dict(urllib.parse.parse_qsl(u.query)), s.rfile, n))
            if n > 1_000_000:
                raise ValueError("Request too large.")
            body = json.loads(s.rfile.read(n) or b"{}")
            if u.path in POST:
                return s.send(POST[u.path](body))
            s.send({"error": "not found"}, 404)
        except Exception as e:
            s.send({"error": str(e)}, 400)


def main():
    global PORT
    threading.Thread(target=load_manifest, daemon=True).start()
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    PORT = srv.server_address[1]
    url = f"http://127.0.0.1:{PORT}/"
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        import webview  # optional: pip install pywebview  (gives a real app window)
        webview.create_window("Ratity Launcher", url, width=1220, height=800)
        webview.start()
    except ImportError:
        webbrowser.open(url)
        print(f"Launcher running at {url}\nKeep this window open. Press Ctrl+C to quit.")
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()

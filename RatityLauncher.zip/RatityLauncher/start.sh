#!/bin/sh
cd "$(dirname "$0")"
python3 mc_launcher.py

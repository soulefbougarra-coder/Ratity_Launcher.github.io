"use strict";
const $ = id => document.getElementById(id);
const TITLES = {home: "Overview", mods: "Mods", packs: "Resource Packs", settings: "Settings"};
let S = null;

async function api(path, body) {
  const opt = body === undefined ? {} : {method: "POST", headers: {"X-Launcher": "1", "Content-Type": "application/json"}, body: JSON.stringify(body)};
  const r = await fetch(path, opt), d = await r.json();
  if (!r.ok || d.error) throw new Error(d.error || "Request failed");
  return d;
}
function toast(m) {
  const t = $("toast"); t.textContent = m; t.classList.add("show");
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove("show"), 4000);
}
const guard = fn => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message); } };
function h(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }
const size = n => n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";

document.querySelectorAll(".nav").forEach(b => b.onclick = () => {
  document.querySelectorAll(".nav").forEach(x => x.classList.toggle("active", x === b));
  document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === b.dataset.page));
  $("pageTitle").textContent = TITLES[b.dataset.page];
});

function fileList(el, items, kind) {
  el.replaceChildren();
  if (!items.length) el.append(h("div", "empty", "Nothing installed yet."));
  items.forEach(f => {
    const row = h("div", "file-item"), info = h("div", "info");
    info.append(h("b", "", f.name), h("small", "", size(f.size)));
    const rm = h("button", "secondary", "Remove");
    rm.onclick = guard(async () => { await api("/api/remove", {kind, name: f.name}); await refresh(); });
    row.append(h("div", "ico", kind === "mods" ? "▦" : "▧"), info, rm);
    el.append(row);
  });
}
function results(el, kind, hits) {
  el.replaceChildren();
  if (!hits.length) el.append(h("div", "empty", "No results for this Minecraft version."));
  hits.forEach(x => {
    const row = h("div", "file-item"), info = h("div", "info");
    let ico = h("div", "ico", x.title.slice(0, 1).toUpperCase());
    if (x.icon) {
      const img = new Image(); img.alt = ""; img.src = `/icon/${x.id}?u=${encodeURIComponent(x.icon)}`;
      img.onload = () => ico.replaceWith(img);
    }
    info.append(h("b", "", `${x.title} · ${x.author}`), h("small", "", `${x.downloads.toLocaleString()} downloads · ${x.desc}`));
    const btn = h("button", "primary", "Install"); btn.style.padding = "9px 18px";
    btn.onclick = guard(async () => {
      btn.disabled = true; btn.textContent = "Installing…";
      try { const r = await api("/api/install", {kind, id: x.id}); toast("Installed: " + r.installed.join(", ")); await refresh(); btn.textContent = "Installed"; }
      catch (e) { btn.disabled = false; btn.textContent = "Install"; throw e; }
    });
    row.append(ico, info, btn); el.append(row);
  });
}

function render(st) {
  S = st; const c = st.cfg;
  if (!$("version").dataset.ready || $("version").options.length !== st.versions.length) {
    $("version").replaceChildren(...st.versions.map(v => new Option(v, v))); $("version").dataset.ready = 1;
  }
  $("version").value = c.ver; $("loader").value = c.loader; $("ram").value = c.ram;
  if (document.activeElement !== $("profile")) $("profile").value = c.profile;
  $("optimization").checked = c.opt;
  $("accountLabel").textContent = "Offline · " + c.user; $("javaPathLabel").textContent = "Java: " + c.java;
  $("modCount").textContent = st.mods.length; $("packCount").textContent = st.packs.length;
  fileList($("modsList"), st.mods, "mods"); fileList($("packsList"), st.packs, "packs");
  $("cpuStat").textContent = st.sys.cpu + " threads"; $("ramStat").textContent = (st.sys.ram / 1024).toFixed(1) + " GB"; $("osStat").textContent = st.sys.os;
  status(st);
}
function status(st) {
  $("statusText").textContent = st.text; $("bar").style.width = st.pct + "%";
  $("launchBtn").disabled = st.running; $("launchBtn").textContent = st.running ? "● RUNNING" : "▶   LAUNCH MINECRAFT";
}
const refresh = async () => render(await api("/api/state"));
const setCfg = guard(async patch => render(await api("/api/config", patch)));

$("profile").onchange = () => setCfg({profile: $("profile").value});
$("version").onchange = () => setCfg({ver: $("version").value});
$("loader").onchange = () => setCfg({loader: $("loader").value});
$("ram").onchange = () => setCfg({ram: $("ram").value});
$("optimization").onchange = () => setCfg({opt: $("optimization").checked});
$("signinBtn").onclick = () => { const u = prompt("Username (3-16 letters, numbers or _):", S.cfg.user); if (u) setCfg({user: u.trim()}); };
$("pickJava").onclick = () => { const j = prompt("Path to java / javaw.exe (or just: java)", S.cfg.java); if (j) setCfg({java: j.trim()}); };
$("launchBtn").onclick = guard(async () => { await api("/api/launch", {}); toast("Starting Minecraft…"); });
$("openGame").onclick = guard(() => api("/api/open", {what: "game"}));
$("openProfiles").onclick = guard(() => api("/api/open", {what: "profiles"}));
$("applyPacks").onclick = guard(() => api("/api/open", {what: "packs"}));

function addFiles(kind, accept) {
  const i = document.createElement("input"); i.type = "file"; i.multiple = true; i.accept = accept;
  i.onchange = guard(async () => {
    for (const f of i.files) {
      const r = await fetch(`/api/upload?kind=${kind}&name=${encodeURIComponent(f.name)}`, {method: "POST", headers: {"X-Launcher": "1"}, body: f});
      const d = await r.json(); if (!r.ok) throw new Error(d.error);
    }
    toast("Added."); await refresh();
  });
  i.click();
}
$("addMods").onclick = () => addFiles("mods", ".jar");
$("addPacks").onclick = () => addFiles("packs", ".zip");

const search = (kind, q, out) => guard(async () => {
  out.replaceChildren(h("div", "empty", "Searching Modrinth…"));
  results(out, kind, await api(`/api/search?kind=${kind}&q=${encodeURIComponent(q.value.trim())}`));
});
const updates = kind => guard(async () => {
  toast("Checking for updates…");
  const ups = await api("/api/updates", {kind});
  if (!ups.length) return toast("Everything is up to date.");
  if (!confirm(`${ups.length} update(s):\n\n` + ups.slice(0, 12).map(u => `• ${u.old} → ${u.new}`).join("\n") + "\n\nUpdate all?")) return;
  const r = await api("/api/apply", {kind}); toast(`Updated ${r.updated} file(s).`); await refresh();
});
$("modSearch").onclick = search("mods", $("modQ"), $("modResults"));
$("packSearch").onclick = search("packs", $("packQ"), $("packResults"));
$("modQ").onkeydown = e => e.key === "Enter" && $("modSearch").click();
$("packQ").onkeydown = e => e.key === "Enter" && $("packSearch").click();
$("modUpdate").onclick = updates("mods"); $("packUpdate").onclick = updates("packs");
$("boost").onclick = guard(async () => {
  if (!confirm("Install Sodium, Lithium, FerriteCore, ModernFix, ImmediatelyFast and Entity Culling (Fabric) for higher FPS and faster loading?")) return;
  toast("Installing performance mods…");
  const r = await api("/api/boost", {}); toast(`Installed ${r.ok.length} mod(s)` + (r.bad.length ? `. Not available for this version: ${r.bad.join(", ")}` : "."));
  await refresh();
});

refresh().catch(e => toast(e.message));
setInterval(() => api("/api/status").then(st => { status(st); if (S && S.running !== st.running) refresh(); }).catch(() => {}), 1200);
